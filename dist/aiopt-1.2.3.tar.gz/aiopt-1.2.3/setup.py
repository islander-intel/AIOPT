from setuptools import setup,find_packages
# python setup.py sdist bdist_wheel
setup(
    name="aiopt",
    version="1.2.3",
    packages= find_packages()
)