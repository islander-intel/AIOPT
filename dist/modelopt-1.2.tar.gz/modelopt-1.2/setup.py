from setuptools import setup,find_packages

setup(
    name="modelopt",
    version="1.2",
    packages= find_packages()
)