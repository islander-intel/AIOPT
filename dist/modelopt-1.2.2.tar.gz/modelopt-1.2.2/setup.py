from setuptools import setup,find_packages
# python setup.py sdist bdist_wheel
setup(
    name="modelopt",
    version="1.2.2",
    packages= find_packages()
)